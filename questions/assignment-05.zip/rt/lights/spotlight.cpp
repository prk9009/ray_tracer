#include <rt/lights/spotlight.h>

namespace rt {

SpotLight::SpotLight(const Point& position, const Vector& direction, float angle, float power, const RGBColor& intensity)
{
    /* TODO */
}

RGBColor SpotLight::getIntensity(const LightHit& irr) const {
    /* TODO */ NOT_IMPLEMENTED;
}

}
