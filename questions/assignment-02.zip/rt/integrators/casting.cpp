#include <rt/integrators/casting.h>

namespace rt {

RGBColor RayCastingIntegrator::getRadiance(const Ray& ray) const {
    /* TODO */ NOT_IMPLEMENTED;
}

}
