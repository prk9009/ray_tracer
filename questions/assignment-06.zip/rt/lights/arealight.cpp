#include <rt/lights/arealight.h>

#include <core/color.h>

namespace rt {

LightHit AreaLight::getLightHit(const Point& p) const {
    /* TODO */ NOT_IMPLEMENTED;
}

RGBColor AreaLight::getIntensity(const LightHit& irr) const {
    /* TODO */ NOT_IMPLEMENTED;
}

AreaLight::AreaLight(Solid* source)
{
    /* TODO */
}

}