#include <rt/coordmappers/spherical.h>

namespace rt {

SphericalCoordMapper::SphericalCoordMapper(const Point& origin, const Vector& zenith, const Vector& azimuthRef)
{
    /* TODO */
}

Point SphericalCoordMapper::getCoords(const Intersection& hit) const {
    /* TODO */ NOT_IMPLEMENTED;
}

}