#include <rt/coordmappers/cylindrical.h>

namespace rt {

CylindricalCoordMapper::CylindricalCoordMapper(const Point& origin, const Vector& longitudinalAxis, const Vector& polarAxis)
{
    /* TODO */
}

Point CylindricalCoordMapper::getCoords(const Intersection& hit) const {
    /* TODO */ NOT_IMPLEMENTED;
}

}