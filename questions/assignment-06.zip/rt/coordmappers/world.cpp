#include <rt/coordmappers/world.h>

namespace rt {

Point WorldMapper::getCoords(const Intersection& hit) const {
    /* TODO */ NOT_IMPLEMENTED;
}

WorldMapper::WorldMapper()
{
    /* TODO */
}

WorldMapper::WorldMapper(const Vector& scale)
{
    /* TODO */
}

}