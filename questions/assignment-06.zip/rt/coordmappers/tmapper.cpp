#include <rt/coordmappers/tmapper.h>

namespace rt {

TriangleMapper::TriangleMapper(Point ntv[3])
{
    /* TODO */
}

TriangleMapper::TriangleMapper(const Point& tv0, const Point& tv1, const Point& tv2)
{
    /* TODO */
}

Point TriangleMapper::getCoords(const Intersection& hit) const {
    /* TODO */ NOT_IMPLEMENTED;
}

}