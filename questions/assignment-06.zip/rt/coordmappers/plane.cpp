#include <rt/coordmappers/plane.h>

namespace rt {

PlaneCoordMapper::PlaneCoordMapper(const Vector& e1, const Vector& e2) {
    /* TODO */
}

Point PlaneCoordMapper::getCoords(const Intersection& hit) const {
    /* TODO */ NOT_IMPLEMENTED;
}

}