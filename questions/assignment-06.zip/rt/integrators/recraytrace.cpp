#include <rt/integrators/recraytrace.h>

namespace rt {

RGBColor RecursiveRayTracingIntegrator::getRadiance(const Ray& ray) const {
    /* TODO */ NOT_IMPLEMENTED;
}

}