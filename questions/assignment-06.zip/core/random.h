#ifndef CG1RAYTRACER_RANDOM_HEADER
#define CG1RAYTRACER_RANDOM_HEADER

namespace rt {

float random();
float random(float max);
float random(float min, float max);

}

#endif